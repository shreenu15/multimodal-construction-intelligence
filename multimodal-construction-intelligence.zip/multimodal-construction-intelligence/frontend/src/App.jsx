import React, { useMemo, useState } from 'react';
import {
  Activity, ArrowDownRight, ArrowUpRight, Bell, CalendarDays, CheckCircle2,
  ChevronDown, ClipboardCheck, CloudSun, HardHat, ImagePlus, LayoutDashboard,
  MessageCircle, Search, Send, ShieldAlert, Sparkles, TriangleAlert, UploadCloud,
  Wallet, Wrench, Menu, X, FileText, Clock3
} from 'lucide-react';

const API = (import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000').replace(/\/$/, '');

const activities = [
  { icon: ClipboardCheck, title: 'Daily safety checklist', meta: 'Zone A · Site operations', time: '09:42 AM', status: 'Completed', tone: 'green' },
  { icon: ImagePlus, title: 'Concrete surface photo added', meta: 'Tower 2 · Inspection', time: 'Yesterday', status: 'Review needed', tone: 'amber' },
  { icon: Wallet, title: 'Material estimate updated', meta: 'Residential block · Budget', time: 'Yesterday', status: 'Updated', tone: 'blue' },
];

function App() {
  const [active, setActive] = useState('Overview');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [image, setImage] = useState(null);
  const [imageResult, setImageResult] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [area, setArea] = useState(1200);
  const [rate, setRate] = useState(1800);
  const [contingency, setContingency] = useState(10);
  const [estimateResult, setEstimateResult] = useState(null);
  const [question, setQuestion] = useState('');
  const [chat, setChat] = useState([{ role: 'assistant', text: 'Hi! I can help with general construction planning, budgeting, and site-safety checklists. What are you working on?' }]);
  const [chatLoading, setChatLoading] = useState(false);
  const [toast, setToast] = useState('');

  const total = useMemo(() => Number(area || 0) * Number(rate || 0) * (1 + Number(contingency || 0) / 100), [area, rate, contingency]);
  const money = (value) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);

  const nav = [
    { name: 'Overview', icon: LayoutDashboard },
    { name: 'Site inspection', icon: ImagePlus },
    { name: 'Safety centre', icon: HardHat },
    { name: 'Cost estimator', icon: Wallet },
    { name: 'AI assistant', icon: MessageCircle },
  ];

  function notify(message) {
    setToast(message);
    window.setTimeout(() => setToast(''), 3200);
  }

  async function inspectImage() {
    if (!image) return notify('Choose a site image first.');
    setAnalyzing(true); setImageResult(null);
    try {
      const form = new FormData(); form.append('image', image);
      const response = await fetch(`${API}/api/analyze-image`, { method: 'POST', body: form });
      if (!response.ok) throw new Error('API unavailable');
      setImageResult(await response.json());
    } catch {
      setImageResult({ status: 'demo_offline', findings: [
        { severity: 'warning', title: 'Manual review recommended', detail: 'The backend could not be reached. Please inspect the image with a qualified site engineer; this demo does not certify structural safety.' },
        { severity: 'info', title: 'Frontend upload ready', detail: 'Start the FastAPI backend to enable the image upload endpoint.' }
      ]});
    } finally { setAnalyzing(false); }
  }

  async function calculateEstimate() {
    try {
      const response = await fetch(`${API}/api/estimate`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ area_sqft: Number(area), rate_per_sqft: Number(rate), contingency_percent: Number(contingency), location: 'India' })
      });
      if (!response.ok) throw new Error();
      setEstimateResult(await response.json());
    } catch {
      setEstimateResult({ total_estimate: total, base_estimate: Number(area) * Number(rate), contingency: Number(area) * Number(rate) * Number(contingency) / 100, note: 'Calculated in the browser because the backend is unavailable. Illustrative only.' });
    }
  }

  async function sendQuestion(e) {
    e.preventDefault();
    if (!question.trim()) return;
    const q = question.trim();
    setChat(prev => [...prev, { role: 'user', text: q }]); setQuestion(''); setChatLoading(true);
    try {
      const response = await fetch(`${API}/api/assistant`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: q }) });
      if (!response.ok) throw new Error();
      const data = await response.json();
      setChat(prev => [...prev, { role: 'assistant', text: data.answer }]);
    } catch {
      setChat(prev => [...prev, { role: 'assistant', text: 'I can help with general planning, budgeting, and safety checklists. For suspected structural issues, restrict access and consult a qualified structural engineer. Start the backend to enable the assistant endpoint.' }]);
    } finally { setChatLoading(false); }
  }

  function selectNav(name) { setActive(name); setMobileMenu(false); }
  const showOverview = active === 'Overview';
  const showInspection = active === 'Site inspection';
  const showSafety = active === 'Safety centre';
  const showCost = active === 'Cost estimator';
  const showAssistant = active === 'AI assistant';

  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu ? 'open' : ''}`}>
      <div className="brand"><div className="brand-mark"><HardHat size={22}/></div><div><strong>SiteSense</strong><span>CONSTRUCTION INTELLIGENCE</span></div><button className="close-menu" onClick={() => setMobileMenu(false)}><X size={18}/></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <div className="project-switch"><div className="project-avatar">R</div><div><b>Riverside Residences</b><small>Project workspace</small></div><ChevronDown size={15}/></div>
      <div className="nav-label">MENU</div>
      <nav>{nav.map(item => <button key={item.name} className={`nav-item ${active === item.name ? 'active' : ''}`} onClick={() => selectNav(item.name)}><item.icon size={18}/><span>{item.name}</span>{item.name === 'Safety centre' && <i className="nav-dot"/>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><Sparkles size={17}/></div><b>Smarter site decisions</b><p>Keep your project data, inspections and plans in one place.</p><button onClick={() => selectNav('AI assistant')}>Ask the assistant <ArrowUpRight size={14}/></button></div><div className="profile"><div className="profile-avatar">SS</div><div><b>Shreenu Sharma</b><small>Project member</small></div><ChevronDown size={15}/></div></div>
    </aside>
    {mobileMenu && <button className="scrim" onClick={() => setMobileMenu(false)} aria-label="Close menu"/>}
    <main className="main-area">
      <header className="topbar"><button className="mobile-menu" onClick={() => setMobileMenu(true)}><Menu/></button><div className="crumb">Projects <span>/</span> <b>Riverside Residences</b></div><div className="top-actions"><div className="search-box"><Search size={16}/><input placeholder="Search anything..." /></div><button className="icon-button" aria-label="Notifications" onClick={() => notify('You’re all caught up!')}><Bell size={18}/><i/></button><div className="top-avatar">SS</div></div></header>
      <div className="content">
        <section className="page-heading"><div><div className="eyebrow"><span className="live-dot"/> PROJECT WORKSPACE <span className="eyebrow-sep">/</span> OCTOBER 2026</div><h1>{showOverview ? 'Good evening, Shreenu' : active}<span className="heading-period">.</span></h1><p>{showOverview ? 'Here’s what’s happening across your construction project.' : ({'Site inspection':'Upload a site photo to start an inspection demo.','Safety centre':'A practical checklist for daily site safety reviews.','Cost estimator':'Build a quick, illustrative project cost estimate.','AI assistant':'Ask general questions about planning, budgets, and site workflows.'})[active]}</p></div><button className="primary-button" onClick={() => selectNav('Site inspection')}><ImagePlus size={16}/> New inspection</button></section>

        {showOverview && <>
          <div className="hero-banner"><div className="hero-copy"><div className="hero-pill"><Sparkles size={13}/> PROJECT PULSE</div><h2>Build with clarity.<br/><em>Plan with confidence.</em></h2><p>Bring site observations, safety checks and cost planning into one clear workspace.</p><button onClick={() => selectNav('Safety centre')}>Review site safety <ArrowUpRight size={15}/></button></div><div className="hero-art" aria-hidden="true"><div className="sun"/><div className="building building-back"><i/><i/><i/><i/><i/><i/></div><div className="building building-front"><i/><i/><i/><i/><i/><i/><i/><i/></div><div className="crane"><b/><i/><span/></div><div className="ground"/></div><div className="hero-number"><span>DEMO PROJECT</span><b>RS<span>.</span>024</b></div></div>
          <div className="stats-grid">
            <Stat icon={ClipboardCheck} label="Safety checklists" value="12" delta="3 this week" tone="mint" />
            <Stat icon={ImagePlus} label="Site inspections" value="08" delta="2 need review" tone="violet" />
            <Stat icon={Wallet} label="Budget tracked" value="₹24.8L" delta="Demo estimate" tone="amber" />
            <Stat icon={Activity} label="Project health" value="Good" delta="Prototype status" tone="blue" />
          </div>
          <div className="section-grid"><section className="panel activity-panel"><div className="panel-heading"><div><h3>Recent activity</h3><p>Latest updates from your workspace</p></div><button className="text-button" onClick={() => notify('You are viewing all demo activity.')}>View all <ArrowUpRight size={14}/></button></div><div className="activity-list">{activities.map((a,i)=><div className="activity-row" key={a.title}><div className={`activity-icon ${a.tone}`}><a.icon size={17}/></div><div className="activity-copy"><b>{a.title}</b><span>{a.meta}</span></div><span className={`status-badge ${a.tone}`}>{a.status}</span><time>{a.time}</time></div>)}</div></section>
          <section className="panel safety-panel"><div className="panel-heading"><div><h3>Safety snapshot</h3><p>Daily readiness checklist</p></div><div className="round-icon"><ShieldAlert size={18}/></div></div><div className="safety-score"><div className="score-ring"><div><b>4/5</b><span>checks</span></div></div><div><b>Almost ready</b><p>One checklist item remains.</p><span className="mini-tag">DEMO DATA</span></div></div><div className="progress-track"><span style={{width:'80%'}}/></div><div className="check-row"><CheckCircle2 size={16}/><span>PPE and helmets</span><b>Done</b></div><div className="check-row"><CheckCircle2 size={16}/><span>Access routes clear</span><b>Done</b></div><div className="check-row pending"><TriangleAlert size={16}/><span>Scaffold inspection log</span><b>Review</b></div><button className="outline-button full" onClick={() => selectNav('Safety centre')}>Open safety centre <ArrowUpRight size={15}/></button></section></div>
          <section className="panel quick-panel"><div className="panel-heading"><div><h3>Quick tools</h3><p>Jump straight into your next task</p></div></div><div className="quick-grid"><Quick icon={ImagePlus} title="Inspect a site image" text="Upload a photo for a demo review" onClick={() => selectNav('Site inspection')} tone="mint"/><Quick icon={Wallet} title="Estimate project costs" text="Calculate an indicative budget" onClick={() => selectNav('Cost estimator')} tone="amber"/><Quick icon={MessageCircle} title="Ask the assistant" text="Get a planning checklist or guidance" onClick={() => selectNav('AI assistant')} tone="violet"/></div></section>
        </>}

        {showInspection && <div className="tool-layout"><section className="panel tool-panel"><div className="panel-heading"><div><h3>Site image inspection</h3><p>Upload a JPG, PNG or WEBP photo</p></div><div className="round-icon"><ImagePlus size={18}/></div></div><label className="upload-zone">{image ? <><div className="upload-symbol"><CheckCircle2/></div><b>{image.name}</b><span>{(image.size/1024/1024).toFixed(2)} MB · Ready to review</span></> : <><div className="upload-symbol"><UploadCloud/></div><b>Drop your site photo here</b><span>or click to browse files · max 12 MB</span></>}<input type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>{setImage(e.target.files?.[0] || null);setImageResult(null)}}/></label>{image && <div className="image-preview"><img src={URL.createObjectURL(image)} alt="Selected construction site preview"/></div>}<button className="primary-button wide" disabled={!image || analyzing} onClick={inspectImage}>{analyzing ? 'Reviewing image…' : 'Run demo inspection'} <ArrowUpRight size={15}/></button><div className="disclaimer"><TriangleAlert size={16}/><span>This prototype does not run a validated vision model. It cannot identify defects reliably or certify a structure as safe.</span></div></section><section className="panel tool-panel"><div className="panel-heading"><div><h3>Inspection report</h3><p>Review notes and next steps</p></div></div>{!imageResult ? <div className="empty-state"><div className="empty-illustration"><FileText size={30}/></div><b>No report yet</b><p>Choose a photo and run the demo inspection to see the workflow.</p></div> : <div className="findings"><div className="result-banner"><CheckCircle2 size={17}/><div><b>Image workflow complete</b><span>{imageResult.filename || 'Uploaded image'}</span></div></div>{imageResult.findings?.map((f,i)=><div className={`finding ${f.severity}`} key={i}><div className="finding-dot"/><div><b>{f.title}</b><p>{f.detail}</p></div></div>)}<p className="small-disclaimer">{imageResult.disclaimer || 'Demo results only; consult a qualified professional.'}</p></div>}</section></div>}

        {showSafety && <div className="safety-page-grid"><section className="panel tool-panel"><div className="panel-heading"><div><h3>Daily site checklist</h3><p>Example checklist · verify on site</p></div><span className="mini-tag">DEMO</span></div>{['PPE: helmets, footwear and high-visibility clothing','Scaffolds and ladders inspected by a competent person','Edges, openings and fall protection secured','Walkways clear and housekeeping maintained','Electrical cables and equipment checked','Emergency exits, first aid and fire equipment accessible'].map((t,i)=><label className="safety-check" key={t}><input type="checkbox" defaultChecked={i===0 || i===1 || i===3 || i===5}/><span className="custom-check"><CheckCircle2 size={16}/></span><span>{t}</span><small>{i===2 ? 'IMPORTANT' : 'CHECK'}</small></label>)}<div className="disclaimer"><TriangleAlert size={16}/><span>This checklist is a starting point, not a substitute for local regulations or your approved site safety plan.</span></div></section><section className="panel tool-panel"><div className="panel-heading"><div><h3>Site conditions</h3><p>General reminders</p></div><div className="round-icon"><CloudSun size={18}/></div></div><div className="condition-card"><div className="condition-icon"><HardHat size={22}/></div><div><b>Before work starts</b><p>Hold a toolbox talk, review task hazards, confirm PPE and check that workers understand emergency procedures.</p></div></div><div className="condition-card"><div className="condition-icon amber"><Clock3 size={22}/></div><div><b>During the shift</b><p>Keep access routes clear, report near misses promptly and stop work if an unsafe condition is found.</p></div></div><div className="condition-card"><div className="condition-icon violet"><ClipboardCheck size={22}/></div><div><b>At handover</b><p>Record observations, assign corrective actions and confirm that unresolved hazards are communicated.</p></div></div></section></div>}

        {showCost && <div className="tool-layout"><section className="panel tool-panel"><div className="panel-heading"><div><h3>Project cost estimator</h3><p>Adjust the assumptions below</p></div><div className="round-icon"><Wallet size={18}/></div></div><div className="field-group"><label>Built-up area <span>square feet</span></label><div className="input-with-unit"><input type="number" min="0" value={area} onChange={e=>setArea(e.target.value)}/><span>sq ft</span></div></div><div className="field-group"><label>Indicative rate <span>per square foot</span></label><div className="input-with-unit"><span>₹</span><input type="number" min="0" value={rate} onChange={e=>setRate(e.target.value)}/><span>/ sq ft</span></div></div><div className="field-group"><label>Contingency allowance <b>{contingency}%</b></label><input className="range" type="range" min="0" max="25" value={contingency} onChange={e=>setContingency(e.target.value)}/><div className="range-labels"><span>0%</span><span>25%</span></div></div><button className="primary-button wide" onClick={calculateEstimate}>Calculate estimate <ArrowUpRight size={15}/></button><p className="small-disclaimer">Illustrative only. Validate rates and scope with a local quantity surveyor or construction professional.</p></section><section className="panel estimate-result"><div className="result-kicker"><span className="live-dot"/> INDICATIVE PROJECT BUDGET</div><p className="estimate-label">Estimated total</p><h2>{money(estimateResult ? estimateResult.total_estimate : total)}</h2><span className="mini-tag">NOT A QUOTATION</span><div className="estimate-breakdown"><div><span>Base estimate</span><b>{money(estimateResult ? estimateResult.base_estimate : Number(area||0)*Number(rate||0))}</b></div><div><span>Contingency</span><b>{money(estimateResult ? estimateResult.contingency : Number(area||0)*Number(rate||0)*Number(contingency||0)/100)}</b></div></div><div className="estimate-note"><TriangleAlert size={16}/><p>{estimateResult?.note || 'This rough calculation excludes detailed design, permissions, taxes, services, site-specific conditions and market fluctuations.'}</p></div></section></div>}

        {showAssistant && <section className="panel chat-panel"><div className="panel-heading"><div><h3>Construction assistant</h3><p>General project guidance · demo mode</p></div><div className="assistant-status"><span className="live-dot"/> READY</div></div><div className="chat-messages">{chat.map((m,i)=><div className={`chat-message ${m.role}`} key={i}><div className="chat-avatar">{m.role==='assistant' ? <Sparkles size={16}/> : 'SS'}</div><div className="chat-bubble"><span>{m.role==='assistant' ? 'SITESENSE ASSISTANT' : 'YOU'}</span><p>{m.text}</p></div></div>)}{chatLoading && <div className="typing">Assistant is thinking…</div>}</div><form className="chat-form" onSubmit={sendQuestion}><input value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Ask about planning, costs or safety…" /><button type="submit" disabled={chatLoading || !question.trim()}><Send size={17}/></button></form><div className="prompt-chips"><button onClick={()=>setQuestion('What should be included in a daily site safety checklist?')}>Daily safety checklist</button><button onClick={()=>setQuestion('How do I plan a construction project timeline?')}>Project timeline</button><button onClick={()=>setQuestion('How should I estimate a construction budget?')}>Budget basics</button></div><p className="small-disclaimer chat-disclaimer">Demo assistant, not a substitute for professional engineering, safety, legal or financial advice.</p></section>}

        <footer className="footer"><span>© 2026 SiteSense · Construction Intelligence</span><span><i/> Prototype workspace · Demo data</span></footer>
      </div>
    </main>
    {toast && <div className="toast"><CheckCircle2 size={17}/>{toast}</div>}
  </div>;
}

function Stat({icon:Icon,label,value,delta,tone}) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={18}/></div><span className="stat-label">{label}</span><b className="stat-value">{value}</b><span className="stat-delta"><ArrowUpRight size={13}/>{delta}</span></div>;
}
function Quick({icon:Icon,title,text,onClick,tone}) {
  return <button className="quick-card" onClick={onClick}><div className={`quick-icon ${tone}`}><Icon size={19}/></div><div><b>{title}</b><span>{text}</span></div><ArrowUpRight className="quick-arrow" size={17}/></button>;
}
export default App;
