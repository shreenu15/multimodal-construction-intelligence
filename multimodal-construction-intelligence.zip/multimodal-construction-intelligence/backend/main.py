from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import os

app = FastAPI(title="Construction Intelligence API", version="0.1.0")

# For a public production deployment, replace "*" with your exact frontend domain.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

class EstimateRequest(BaseModel):
    area_sqft: float = 1200
    rate_per_sqft: float = 1800
    contingency_percent: float = 10
    location: Optional[str] = "India"

class AssistantRequest(BaseModel):
    message: str

@app.get("/")
def root():
    return {"message": "Construction Intelligence API is running", "docs": "/docs"}

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "construction-intelligence-api", "mode": "prototype"}

@app.post("/api/estimate")
def estimate(req: EstimateRequest):
    area = max(0, req.area_sqft)
    rate = max(0, req.rate_per_sqft)
    subtotal = area * rate
    contingency = subtotal * max(0, req.contingency_percent) / 100
    return {
        "location": req.location or "Not specified",
        "area_sqft": area,
        "rate_per_sqft": rate,
        "base_estimate": round(subtotal, 2),
        "contingency": round(contingency, 2),
        "total_estimate": round(subtotal + contingency, 2),
        "currency": "INR",
        "note": "Illustrative estimate only. Actual costs depend on location, design, materials, labour, taxes, and site conditions."
    }

@app.post("/api/analyze-image")
async def analyze_image(image: UploadFile = File(...)):
    allowed = {"image/jpeg", "image/png", "image/webp"}
    if image.content_type not in allowed:
        return {"status": "unsupported", "filename": image.filename, "findings": [
            {"severity": "info", "title": "Unsupported file type", "detail": "Upload a JPG, PNG, or WEBP image."}
        ]}
    content = await image.read()
    if len(content) > 12 * 1024 * 1024:
        return {"status": "too_large", "filename": image.filename, "findings": [
            {"severity": "warning", "title": "Image too large", "detail": "Please upload an image smaller than 12 MB."}
        ]}
    # This is intentionally a demo response, not computer vision.
    return {
        "status": "demo_complete",
        "filename": image.filename,
        "size_bytes": len(content),
        "findings": [
            {"severity": "warning", "title": "Manual review recommended", "detail": "This prototype does not run a validated vision model. Ask a qualified site engineer to inspect visible defects."},
            {"severity": "info", "title": "Image received", "detail": "The image upload pipeline is working. A trained vision model can be connected in a later iteration."}
        ],
        "disclaimer": "Not a structural safety assessment. Do not use this result to determine whether a building is safe."
    }

@app.post("/api/assistant")
def assistant(req: AssistantRequest):
    message = req.message.strip()
    if not message:
        return {"answer": "Tell me a little more about your construction question."}
    lower = message.lower()
    if any(word in lower for word in ["crack", "structural", "collapse", "unsafe"]):
        answer = ("If you suspect a structural defect, restrict access to the affected area and contact a qualified structural engineer. "
                  "Photographs alone cannot establish structural safety; this demo cannot diagnose cracks.")
    elif any(word in lower for word in ["cost", "budget", "estimate", "price"]):
        answer = ("Start with built-up area × a locally verified rate per square foot, then separately account for design, approvals, labour, "
                  "materials, utilities, taxes, and a contingency. Use the estimator in this demo only as an illustrative starting point.")
    elif any(word in lower for word in ["safety", "ppe", "helmet", "site"]):
        answer = ("A basic site safety review should check PPE, edge protection, housekeeping, access routes, scaffolding, electrical hazards, "
                  "and emergency arrangements. Follow local regulations and your site's approved safety plan.")
    elif any(word in lower for word in ["plan", "schedule", "timeline"]):
        answer = ("Break the work into activities, estimate durations, identify dependencies, assign owners, and track critical-path tasks. "
                  "Confirm the schedule with the project manager and update it as site conditions change.")
    else:
        answer = ("I can help outline construction planning, budgeting, and general site-safety checklists. This starter assistant uses demo rules "
                  "rather than a connected language model, so verify important advice with qualified professionals.")
    return {"answer": answer, "mode": "demo"}
