# Multimodal Construction Intelligence Platform

A starter full-stack demo for construction planning and site intelligence. It includes a React dashboard and a Python FastAPI backend.

## Included demo features
- Construction dashboard with summary cards and recent activity
- Construction image upload interface
- Safety checklist / site observations demo
- Crack inspection demo flow (prototype only; not a certified structural assessment)
- Quick construction cost estimator
- AI-style construction assistant with demo responses
- FastAPI endpoints for health, estimates, image analysis, and assistant responses

> **Important:** This is a functional prototype, not a production safety system. Image findings are simulated heuristics, not a validated computer-vision model. Never use it to make real structural-safety decisions. Have qualified professionals inspect actual sites.

## Requirements
- Python 3.10+
- Node.js 18+ (20+ recommended)

## Run locally

### 1. Start the backend
Open a terminal in this folder:

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

Backend API: http://127.0.0.1:8000  
API docs: http://127.0.0.1:8000/docs

### 2. Start the frontend
Open a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## GitHub upload (browser method)
1. Open your repository on GitHub.
2. Click **Add file → Upload files**.
3. Unzip this downloaded archive on your Mac.
4. Drag the files and folders from the unzipped `multimodal-construction-intelligence` folder into GitHub's upload area.
5. Commit the upload.

Avoid uploading `.venv`, `node_modules`, API keys, passwords, or private data.

## Deployment
For a beginner-friendly demo deployment, deploy the frontend and backend separately:
- Frontend: Vercel or Netlify
- Backend: Render or another Python web host

Set the frontend environment variable `VITE_API_URL` to your deployed backend URL (without a trailing slash). On the backend host, use:
`uvicorn main:app --host 0.0.0.0 --port $PORT`

For a frontend deployed separately, update `backend/main.py` CORS settings to allow your deployed frontend domain instead of `*` before production use.

## Project structure
```text
backend/
  main.py
  requirements.txt
frontend/
  index.html
  package.json
  vite.config.js
  src/
    main.jsx
    App.jsx
    styles.css
```
